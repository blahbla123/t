define(function(require, exports, module) {

    var dom = require("pilot/dom");

    var cssText = "\
.ace-tomorrow-night .ace_editor {\
  border: 2px solid rgb(159, 159, 159);\
}\
\
.ace-tomorrow-night .ace_editor.ace_focus {\
  border: 2px solid #327fbd;\
}\
\
.ace-tomorrow-night .ace_gutter {\
  width: 50px;\
  background: #e8e8e8;\
  color: #333;\
  overflow : hidden;\
}\
\
.ace-tomorrow-night .ace_gutter-layer {\
  width: 100%;\
  text-align: right;\
}\
\
.ace-tomorrow-night .ace_gutter-layer .ace_gutter-cell {\
  padding-right: 6px;\
}\
\
.ace-tomorrow-night .ace_print_margin {\
  width: 1px;\
  background: #e8e8e8;\
}\
\
.ace-tomorrow-night .ace_scroller {\
  background-color: #1D1F21;\
}\
\
.ace-tomorrow-night .ace_text-layer {\
  cursor: text;\
  color: #C5C8C6;\
}\
\
.ace-tomorrow-night .ace_cursor {\
  border-left: 2px solid #AEAFAD;\
}\
\
.ace-tomorrow-night .ace_cursor.ace_overwrite {\
  border-left: 0px;\
  border-bottom: 1px solid #AEAFAD;\
}\
 \
.ace-tomorrow-night .ace_marker-layer .ace_selection {\
  background: #373B41;\
}\
\
.ace-tomorrow-night .ace_marker-layer .ace_step {\
  background: rgb(198, 219, 174);\
}\
\
.ace-tomorrow-night .ace_marker-layer .ace_bracket {\
  margin: -1px 0 0 -1px;\
  border: 1px solid #4B4E55;\
}\
\
.ace-tomorrow-night .ace_marker-layer .ace_active_line {\
  background: #282A2E;\
}\
\
       \
.ace-tomorrow-night .ace_invisible {\
  color: #4B4E55;\
}\
\
.ace-tomorrow-night .ace_keyword {\
  color:#B294BB;\
}\
\
.ace-tomorrow-night .ace_keyword.ace_operator {\
  color:#8ABEB7;\
}\
\
.ace-tomorrow-night .ace_constant {\
  \
}\
\
.ace-tomorrow-night .ace_constant.ace_language {\
  color:#DE935F;\
}\
\
.ace-tomorrow-night .ace_constant.ace_library {\
  \
}\
\
.ace-tomorrow-night .ace_constant.ace_numeric {\
  color:#DE935F;\
}\
\
.ace-tomorrow-night .ace_invalid {\
  color:#CED2CF;\
background-color:#DF5F5F;\
}\
\
.ace-tomorrow-night .ace_invalid.ace_illegal {\
  \
}\
\
.ace-tomorrow-night .ace_invalid.ace_deprecated {\
  color:#CED2CF;\
background-color:#B798BF;\
}\
\
.ace-tomorrow-night .ace_support {\
  \
}\
\
.ace-tomorrow-night .ace_support.ace_function {\
  color:#81A2BE;\
}\
\
.ace-tomorrow-night .ace_function.ace_buildin {\
  \
}\
\
.ace-tomorrow-night .ace_string {\
  color:#B5BD68;\
}\
\
.ace-tomorrow-night .ace_string.ace_regexp {\
  color:#CC6666;\
}\
\
.ace-tomorrow-night .ace_comment {\
  color:#969896;\
}\
\
.ace-tomorrow-night .ace_comment.ace_doc {\
  \
}\
\
.ace-tomorrow-night .ace_comment.ace_doc.ace_tag {\
  \
}\
\
.ace-tomorrow-night .ace_variable {\
  color:#CC6666;\
}\
\
.ace-tomorrow-night .ace_variable.ace_language {\
  \
}\
\
.ace-tomorrow-night .ace_xml_pe {\
  \
}\
\
.ace-tomorrow-night .ace_meta {\
  \
}\
\
.ace-tomorrow-night .ace_meta.ace_tag {\
  color:#CC6666;\
}\
\
.ace-tomorrow-night .ace_meta.ace_tag.ace_input {\
  \
}\
\
.ace-tomorrow-night .ace_entity.ace_other.ace_attribute-name {\
  color:#CC6666;\
}\
\
.ace-tomorrow-night .ace_markup.ace_underline {\
    text-decoration:underline;\
}\
\
.ace-tomorrow-night .ace_markup.ace_heading {\
  color:#B5BD68;\
}\
\
.ace-tomorrow-night .ace_markup.ace_heading.ace_1 {\
  \
}\
\
.ace-tomorrow-night .ace_markup.ace_heading.ace_2 {\
  \
}\
\
.ace-tomorrow-night .ace_markup.ace_heading.ace_3 {\
  \
}\
\
.ace-tomorrow-night .ace_markup.ace_heading.ace_4 {\
  \
}\
\
.ace-tomorrow-night .ace_markup.ace_heading.ace_5 {\
  \
}\
\
.ace-tomorrow-night .ace_markup.ace_heading.ace_6 {\
  \
}\
\
.ace-tomorrow-night .ace_markup.ace_list {\
  \
}\
\
.ace-tomorrow-night .ace_collab.ace_user1 {\
     \
}\
";

    // import CSS once
    dom.importCssString(cssText);

    exports.cssClass = "ace-tomorrow-night";
});