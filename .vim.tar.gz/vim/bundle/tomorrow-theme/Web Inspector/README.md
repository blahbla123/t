# Google Chrome Web Inspector Tomorrow Theme

Copy Custom.css to your user style sheet folder

Mac: 

    ~/Library/Application\ Support/Google/Chrome/Default/User\ StyleSheets/Custom.css

Windows Vista/7: 

    C:\Users\YourUsername\AppData\Local\Google\Chrome\User Data\Default\User StyleSheets\Custom.css

Windows XP:
    C:\Documents and Settings\YourUsername\Local Settings\Application Data\Chrome\User Data\Default\User StyleSheets\Custom.css

Ubuntu (Chromium): 

    ~/.config/chromium/Default/User\ StyleSheets/Custom.css
